﻿open System

printfn "Wprowadź tekst:"
let input = Console.ReadLine()

let words =
    input.Split([|' '; '\n'; '\t'|], StringSplitOptions.RemoveEmptyEntries)
    |> Array.toList

let longestWord =
    words |> List.maxBy (fun w -> w.Length)

printfn "Najdłuższe słowo: %s" longestWord
printfn "Długość słowa: %d" longestWord.Length

0
