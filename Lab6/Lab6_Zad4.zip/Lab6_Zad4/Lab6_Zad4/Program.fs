﻿open System

let przeksztalcWpis (wpis: string) =
    let parts = wpis.Split([|';'|], StringSplitOptions.RemoveEmptyEntries)
    if parts.Length = 3 then
        let imie = parts.[0].Trim()
        let nazwisko = parts.[1].Trim()
        let wiek = parts.[2].Trim()

        let imieZmienione = 
            if imie.Length > 0 then
                imie.Substring(0, 1).ToUpper() + imie.Substring(1).ToLower()
            else imie

        let nazwiskoZmienione = 
            if nazwisko.Length > 0 then
                nazwisko.Substring(0, 1).ToUpper() + nazwisko.Substring(1).ToLower()
            else nazwisko

        printfn "%s, %s (%s lat)" nazwiskoZmienione imieZmienione wiek
    else
        printfn "Błędny format, popraw wprowadzone dane."

let rec main () =
    printfn "Wprowadź dane w formacie 'imię; nazwisko; wiek' lub wpisz 'exit' aby zakończyć:"
    let input = Console.ReadLine()
    if input.ToLower() = "exit" then
        printfn "Zakończono program."
    else
        przeksztalcWpis input
        main ()

main ()