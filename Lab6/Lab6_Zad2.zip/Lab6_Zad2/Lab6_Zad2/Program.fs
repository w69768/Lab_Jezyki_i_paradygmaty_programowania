﻿open System

printfn "Wprowadź dowolny tekst: "
let input2 = Console.ReadLine()

let textWithoutSpace = input2.Replace(" ","").ToLower()
let charCount2 = textWithoutSpace.Length

let mutable i = 0
let mutable isPalindrom = true

while i < charCount2 / 2 && isPalindrom do
    if textWithoutSpace.[i] <> textWithoutSpace.[charCount2 - 1 - i] then
        isPalindrom <- false
    i <- i + 1

printfn "Czy palindrom: %b" isPalindrom

0