namespace LibrarySystem

type User(name: string) =
    let mutable borrowedBooks : Book list = []

    member this.Name = name

    member this.BorrowBook(book: Book) =
        borrowedBooks <- book :: borrowedBooks

    member this.ReturnBook(book: Book) =
        borrowedBooks <- borrowedBooks |> List.filter (fun b -> b <> book)

    member this.ListBorrowedBooks() =
        borrowedBooks
