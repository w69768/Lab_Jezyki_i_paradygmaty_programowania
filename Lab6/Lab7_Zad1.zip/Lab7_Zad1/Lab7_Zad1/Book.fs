namespace LibrarySystem

type Book(title: string, author: string, pages: int) =
    member this.Title = title
    member this.Author = author
    member this.Pages = pages

    member this.GetInfo() =
        sprintf "Tytu�: %s | Autor: %s | Strony: %d" title author pages
