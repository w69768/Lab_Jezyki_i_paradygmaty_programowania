namespace LibrarySystem

type Library() =
    let mutable books : Book list = []

    member this.AddBook(book: Book) =
        books <- book :: books

    member this.RemoveBook(title: string) =
        let bookOpt = books |> List.tryFind (fun b -> b.Title = title)
        match bookOpt with
        | Some book ->
            books <- books |> List.filter (fun b -> b <> book)
            Some book
        | None -> None

    member this.ListBooks() =
        books
