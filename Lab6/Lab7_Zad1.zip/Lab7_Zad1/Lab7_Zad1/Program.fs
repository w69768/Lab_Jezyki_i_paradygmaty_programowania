open System
open LibrarySystem

[<EntryPoint>]
let main argv =
    let library = Library()
    let user = User("Czytelnik")
    let mutable running = true

    while running do
        printfn "\n--- MENU BIBLIOTEKI ---"
        printfn "1. Dodaj ksiazke"
        printfn "2. Usun ksiazke"
        printfn "3. Lista ksiazek"
        printfn "4. Wypozycz ksiazke"
        printfn "5. Zwroc ksiazke"
        printfn "0. Wyjscie"
        printf "Wybierz opcje: "

        match Console.ReadLine() with
        | "1" ->
            printf "Tytul: "
            let title = Console.ReadLine()
            printf "Autor: "
            let author = Console.ReadLine()
            printf "Liczba stron: "
            let pages = int (Console.ReadLine())
            library.AddBook(Book(title, author, pages))
            printfn "Ksiazka dodana."

        | "2" ->
            printf "Tytul ksiazki do usuniecia: "
            let title = Console.ReadLine()
            match library.RemoveBook(title) with
            | Some _ -> printfn "Ksiazka usunieta."
            | None -> printfn "Nie znaleziono ksiazki."

        | "3" ->
            printfn "\n--- KSIazKI W BIBLIOTECE ---"
            library.ListBooks()
            |> List.iter (fun b -> printfn "%s" (b.GetInfo()))

        | "4" ->
            printf "Tytul ksiazki do wypozyczenia: "
            let title = Console.ReadLine()
            match library.RemoveBook(title) with
            | Some book ->
                user.BorrowBook(book)
                printfn "Ksiazka wypozyczona."
            | None ->
                printfn "Brak takiej ksiazki."

        | "5" ->
            printf "Tytul ksiazki do zwrotu: "
            let title = Console.ReadLine()
            let borrowed =
                user.ListBorrowedBooks()
                |> List.tryFind (fun b -> b.Title = title)

            match borrowed with
            | Some book ->
                user.ReturnBook(book)
                library.AddBook(book)
                printfn "Ksiazka zwrocona."
            | None ->
                printfn "Nie masz takiej ksiazki."

        | "0" ->
            running <- false

        | _ ->
            printfn "Niepoprawna opcja."

    0
