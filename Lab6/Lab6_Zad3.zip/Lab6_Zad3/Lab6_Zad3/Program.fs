﻿open System

printfn "Wprowadź ciąg słów oddzielonych spacjami, tabulatorami lub nowymi liniami:"
let input3 = Console.ReadLine()

let words = input3.Split([|' '; '\n'; '\t'|], StringSplitOptions.RemoveEmptyEntries) |> List.ofArray

let uniqueWords = words |> List.distinct

printfn "Unikalne słowa:"
uniqueWords |> List.iter (printfn "%s")

0