﻿open System

printfn "Wprowadź dowolny tekst: "
let input = Console.ReadLine()

let wordCount = input.Split([|' ';'\n';'\t'|],StringSplitOptions.RemoveEmptyEntries).Length
printfn "Liczba słów: %d" wordCount

let charCount = input.Replace(" ","").Length
printfn "Liczba znaków bez spacji: %d" charCount

0