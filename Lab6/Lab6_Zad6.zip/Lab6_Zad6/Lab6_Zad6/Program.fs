﻿open System

let zamienSlowo (tekst: string) (szukane: string) (zamiana: string) =
    tekst.Replace(szukane, zamiana)

let main () =
    printfn "Wprowadź tekst:"
    let tekst = Console.ReadLine()

    printfn "Podaj słowo do wyszukania:"
    let szukane = Console.ReadLine()

    printfn "Podaj nowe słowo:"
    let zamiana = Console.ReadLine()

    let zmodyfikowanyTekst = zamienSlowo tekst szukane zamiana

    printfn "Zmodyfikowany tekst:"
    printfn "%s" zmodyfikowanyTekst

main ()
