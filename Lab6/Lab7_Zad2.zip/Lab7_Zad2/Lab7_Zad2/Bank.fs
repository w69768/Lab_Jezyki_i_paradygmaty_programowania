namespace BankSystem

open System.Collections.Generic

type Bank() =
    let accounts = Dictionary<string, BankAccount>()

    member this.CreateAccount(accountNumber: string) =
        if accounts.ContainsKey(accountNumber) then
            false
        else
            accounts.Add(accountNumber, BankAccount(accountNumber, 0m))
            true

    member this.GetAccount(accountNumber: string) =
        if accounts.ContainsKey(accountNumber) then
            Some accounts[accountNumber]
        else
            None

    member this.UpdateAccount(accountNumber: string, amount: decimal) =
        match this.GetAccount(accountNumber) with
        | Some account ->
            account.Deposit(amount)
        | None -> false

    member this.DeleteAccount(accountNumber: string) =
        accounts.Remove(accountNumber)
