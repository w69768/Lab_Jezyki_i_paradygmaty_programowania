namespace BankSystem

type BankAccount(accountNumber: string, initialBalance: decimal) =
    let mutable balance = initialBalance

    member this.AccountNumber = accountNumber
    member this.Balance = balance

    member this.Deposit(amount: decimal) =
        if amount > 0m then
            balance <- balance + amount
            true
        else
            false

    member this.Withdraw(amount: decimal) =
        if amount > 0m && amount <= balance then
            balance <- balance - amount
            true
        else
            false
