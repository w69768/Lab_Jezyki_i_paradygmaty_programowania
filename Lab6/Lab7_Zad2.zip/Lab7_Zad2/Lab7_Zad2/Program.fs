﻿open System
open BankSystem

[<EntryPoint>]
let main argv =
    let bank = Bank()
    let mutable running = true

    while running do
        printfn "\n--- MENU BANKU ---"
        printfn "1. Utwórz konto"
        printfn "2. Pokaż konto"
        printfn "3. Wpłata"
        printfn "4. Wypłata"
        printfn "5. Usuń konto"
        printfn "0. Wyjście"
        printf "Wybierz opcję: "

        match Console.ReadLine() with
        | "1" ->
            printf "Numer konta: "
            let nr = Console.ReadLine()
            if bank.CreateAccount(nr) then
                printfn "Konto utworzone."
            else
                printfn "Konto już istnieje."

        | "2" ->
            printf "Numer konta: "
            let nr = Console.ReadLine()
            match bank.GetAccount(nr) with
            | Some acc ->
                printfn "Saldo konta %s: %M" acc.AccountNumber acc.Balance
            | None ->
                printfn "Nie znaleziono konta."

        | "3" ->
            printf "Numer konta: "
            let nr = Console.ReadLine()
            printf "Kwota wpłaty: "
            let amount = decimal (Console.ReadLine())
            match bank.GetAccount(nr) with
            | Some acc when acc.Deposit(amount) ->
                printfn "Wpłata wykonana."
            | _ ->
                printfn "Błąd wpłaty."

        | "4" ->
            printf "Numer konta: "
            let nr = Console.ReadLine()
            printf "Kwota wypłaty: "
            let amount = decimal (Console.ReadLine())
            match bank.GetAccount(nr) with
            | Some acc when acc.Withdraw(amount) ->
                printfn "Wypłata wykonana."
            | _ ->
                printfn "Błąd wypłaty."

        | "5" ->
            printf "Numer konta: "
            let nr = Console.ReadLine()
            if bank.DeleteAccount(nr) then
                printfn "Konto usunięte."
            else
                printfn "Nie znaleziono konta."

        | "0" ->
            running <- false

        | _ ->
            printfn "Niepoprawna opcja."

    0
