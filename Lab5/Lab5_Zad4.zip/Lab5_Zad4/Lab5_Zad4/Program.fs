﻿open System

let rec wiezeHanoi liczbaDyskow zrodlo cel pomocnicza =
    if liczbaDyskow = 1 then
        printfn "Przenieś dysk z %s na %s" zrodlo cel
    else
        wiezeHanoi (liczbaDyskow - 1) zrodlo pomocnicza cel
        printfn "Przenieś dysk z %s na %s" zrodlo cel
        wiezeHanoi (liczbaDyskow - 1) pomocnicza cel zrodlo

wiezeHanoi 5 "A" "B" "C"

printfn ""
printfn "Wersja iteracyjna: "

let hanoiIteracyjnie liczbaDyskow =
    let mutable zrodlo = 0
    let mutable cel = 2
    let mutable pomocnicza = 1

    if liczbaDyskow % 2 = 0 then
        let tymczasowa = cel
        cel <- pomocnicza
        pomocnicza <- tymczasowa

    let lacznaLiczbaRuchow = int (Math.Pow(2.0, float liczbaDyskow)) - 1

    let wieze = ['A'; 'C'; 'B']

    for ruch in 1..lacznaLiczbaRuchow do
        let zWiezy = (ruch &&& (ruch - 1)) % 3
        let naWieze = ((ruch ||| (ruch - 1)) + 1) % 3

        printfn "Przenieś dysk z wieży %c na wieżę %c" wieze.[zWiezy] wieze.[naWieze]

hanoiIteracyjnie 5

printfn ""

0