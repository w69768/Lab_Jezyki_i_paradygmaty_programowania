﻿open System

//rekurencja
let rec fib n =
    if n<0 then failwith " n musi być wartością dodatnią"
    elif n=0 then 0
    elif n=1 then 1
    else fib(n-1)+fib(n-2)

//rekurencja ogonowa
let fibTail n =
    let rec loop a b i =
        if i = n then a
        else loop b (a+b) (i+1)
    loop 0 1 0


printfn "fib 5 = %d" (fib 10)
printfn "fib 5 = %d\n"(fibTail 10)

0