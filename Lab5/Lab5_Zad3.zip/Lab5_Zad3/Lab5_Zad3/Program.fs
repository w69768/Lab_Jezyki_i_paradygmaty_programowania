﻿open System

let rec permutacje lista =
    match lista with
    | [] -> [ [] ]
    | x :: xs ->
        permutacje xs
        |> List.collect (fun p ->
            [ for i in 0 .. List.length p do
                let (l, r) = List.splitAt i p
                yield l @ [x] @ r
            ])

[<EntryPoint>]
let main _ =
    printf "Podaj liczby oddzielone spacją: "
    let input = Console.ReadLine()

    let liczby =
        input.Split([|' '; '\t'|], StringSplitOptions.RemoveEmptyEntries)
        |> Array.map int
        |> Array.toList

    let wynik = permutacje liczby

    printfn "\nPermutacje: "
    wynik |> List.iter (fun p -> printfn "%A" p)

    0
