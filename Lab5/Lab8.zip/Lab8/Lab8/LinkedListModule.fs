namespace LinkedListApp

module LinkedListModule =
//1
    let rec fromList (lista: 'T list) : LinkedList<'T> =
        match lista with
        | [] -> Empty
        | x :: xs -> Node(x, fromList xs)

    let rec toList (listaLaczona: LinkedList<'T>) : 'T list =
        match listaLaczona with
        | Empty -> []
        | Node(x, xs) -> x :: toList xs

    let printList (listaLaczona: LinkedList<'T>) : unit =
        printfn "%A" (toList listaLaczona)

//2
    let rec sumList (listaLaczona: LinkedList<int>) : int =
        match listaLaczona with
        | Empty -> 0
        | Node(x, xs) -> x + sumList xs

//3
    let minMax (listaLaczona: LinkedList<'T>) : 'T * 'T when 'T : comparison =
        match listaLaczona with
        | Empty -> failwith "Lista jest pusta - nie mo�na wyznaczy� min i max."
        | Node(pierwszy, reszta) ->
            let rec petla aktualneMin aktualneMax lista =
                match lista with
                | Empty -> (aktualneMin, aktualneMax)
                | Node(x, xs) ->
                    let noweMin = if x < aktualneMin then x else aktualneMin
                    let noweMax = if x > aktualneMax then x else aktualneMax
                    petla noweMin noweMax xs
            petla pierwszy pierwszy reszta

//4
    let reverse (listaLaczona: LinkedList<'T>) : LinkedList<'T> =
        let rec petla acc lista =
            match lista with
            | Empty -> acc
            | Node(x, xs) -> petla (Node(x, acc)) xs
        petla Empty listaLaczona

//5
    let rec contains (wartosc: 'T) (listaLaczona: LinkedList<'T>) : bool =
        match listaLaczona with
        | Empty -> false
        | Node(x, xs) -> (x = wartosc) || contains wartosc xs

//6
    let findIndex (wartosc: 'T) (listaLaczona: LinkedList<'T>) : WynikIndeksu =
        let rec petla idx lista =
            match lista with
            | Empty -> NieZnaleziono
            | Node(x, xs) ->
                if x = wartosc then Znaleziono idx
                else petla (idx + 1) xs
        petla 0 listaLaczona

//7
    let rec countOccurrences (wartosc: 'T) (listaLaczona: LinkedList<'T>) : int =
        match listaLaczona with
        | Empty -> 0
        | Node(x, xs) ->
            (if x = wartosc then 1 else 0) + countOccurrences wartosc xs

//8
    let rec concat (lista1: LinkedList<'T>) (lista2: LinkedList<'T>) : LinkedList<'T> =
        match lista1 with
        | Empty -> lista2
        | Node(x, xs) -> Node(x, concat xs lista2)

//9
    let porownajListy (lista1: LinkedList<int>) (lista2: LinkedList<int>) : LinkedList<bool> =
        let rec petla l1 l2 =
            match l1, l2 with
            | Empty, Empty -> Empty
            | Node(x, xs), Node(y, ys) -> Node(x > y, petla xs ys)
            | _, _ -> failwith "Listy maj� r�n� d�ugo��!"
        petla lista1 lista2

//10
    let filter (warunek: 'T -> bool) (listaLaczona: LinkedList<'T>) : LinkedList<'T> =
        let rec petla acc lista =
            match lista with
            | Empty -> reverse acc
            | Node(x, xs) ->
                if warunek x then petla (Node(x, acc)) xs
                else petla acc xs
        petla Empty listaLaczona

//11
    let removeDuplicates (listaLaczona: LinkedList<'T>) : LinkedList<'T> when 'T : comparison =
        let rec petla (widziane: Set<'T>) acc lista =
            match lista with
            | Empty -> reverse acc
            | Node(x, xs) ->
                if Set.contains x widziane then
                    petla widziane acc xs
                else
                    petla (Set.add x widziane) (Node(x, acc)) xs
        petla Set.empty Empty listaLaczona

//12
    let partition (warunek: 'T -> bool) (listaLaczona: LinkedList<'T>) : LinkedList<'T> * LinkedList<'T> =
        let rec petla accTak accNie lista =
            match lista with
            | Empty -> (reverse accTak, reverse accNie)
            | Node(x, xs) ->
                if warunek x then petla (Node(x, accTak)) accNie xs
                else petla accTak (Node(x, accNie)) xs
        petla Empty Empty listaLaczona