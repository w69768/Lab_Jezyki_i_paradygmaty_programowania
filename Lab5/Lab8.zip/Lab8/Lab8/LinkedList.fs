namespace LinkedListApp

type LinkedList<'T> =
    | Empty
    | Node of 'T * LinkedList<'T>

type WynikIndeksu =
    | Znaleziono of int
    | NieZnaleziono