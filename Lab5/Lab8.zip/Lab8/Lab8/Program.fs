﻿namespace LinkedListApp
open System

module Program =
    let wczytajListeInt () : LinkedList<int> =
        printf "Podaj liczby całkowite oddzielone spacją: "
        let tekst = Console.ReadLine()
        let liczby =
            tekst.Split([|' '; '\t'|], StringSplitOptions.RemoveEmptyEntries)
            |> Array.toList
            |> List.map int
        LinkedListModule.fromList liczby

    let wczytajInt (opis: string) =
        printf "%s" opis
        Console.ReadLine() |> int

    let wyswietlMenu () =
        printfn ""
        printfn "=== MENU ==="
        printfn "1  - Wczytaj listę i zmień na łączoną"
        printfn "2  - Suma elementów"
        printfn "3  - Min i Max"
        printfn "4  - Odwróć listę"
        printfn "5  - Sprawdź czy element istnieje"
        printfn "6  - Znajdź indeks elementu"
        printfn "7  - Policz wystąpienia elementu"
        printfn "8  - Połącz z drugą listą"
        printfn "9  - Porównaj z drugą listą"
        printfn "10 - Filtruj >="
        printfn "11 - Usuń duplikaty"
        printfn "12 - Podziel >="
        printfn "0  - Wyjście"
        printf "Wybór: "
        Console.ReadLine() |> int

    [<EntryPoint>]
    let main _ =
        let mutable userList : LinkedList<int> = Empty

        let mutable dzialaj = true
        while dzialaj do
            let wybor = wyswietlMenu()

            match wybor with
            | 0 ->
                dzialaj <- false

            | 1 ->
                userList <- wczytajListeInt()
                printf "Aktualna lista: "
                LinkedListModule.printList userList

            | 2 ->
                printfn "Suma: %d" (LinkedListModule.sumList userList)

            | 3 ->
                try
                    let (mn, mx) = LinkedListModule.minMax userList
                    printfn "Min: %A, Max: %A" mn mx
                with ex ->
                    printfn "Błąd: %s" ex.Message

            | 4 ->
                userList <- LinkedListModule.reverse userList
                printf "Odwrócona lista: "
                LinkedListModule.printList userList

            | 5 ->
                let wartosc = wczytajInt "Podaj szukaną wartość: "
                printfn "Czy element jest na liście? %b" (LinkedListModule.contains wartosc userList)

            | 6 ->
                let wartosc = wczytajInt "Podaj wartość do znalezienia indeksu: "
                match LinkedListModule.findIndex wartosc userList with
                | Znaleziono i -> printfn "Znaleziono na indeksie: %d" i
                | NieZnaleziono -> printfn "Nie znaleziono elementu."

            | 7 ->
                let wartosc = wczytajInt "Podaj wartość do zliczania: "
                printfn "Liczba wystąpień: %d" (LinkedListModule.countOccurrences wartosc userList)

            | 8 ->
                printfn "Wczytaj drugą listę do połączenia:"
                let druga = wczytajListeInt()
                userList <- LinkedListModule.concat userList druga
                printf "Połączona lista: "
                LinkedListModule.printList userList

            | 9 ->
                try
                    printfn "Wczytaj drugą listę do porównania (musi mieć tę samą długość):"
                    let druga = wczytajListeInt()
                    let wynik = LinkedListModule.porownajListy userList druga
                    printf "Wynik porównania (true gdy 1. większa): "
                    LinkedListModule.printList wynik
                with ex ->
                    printfn "Błąd: %s" ex.Message

            | 10 ->
                let prog = wczytajInt "Podaj próg (zostają elementy >= próg): "
                let przefiltrowana = LinkedListModule.filter (fun x -> x >= prog) userList
                printf "Lista po filtracji: "
                LinkedListModule.printList przefiltrowana

            | 11 ->
                userList <- LinkedListModule.removeDuplicates userList
                printf "Lista bez duplikatów: "
                LinkedListModule.printList userList

            | 12 ->
                let prog = wczytajInt "Podaj próg (podział na >= próg i resztę): "
                let (spelnia, reszta) = LinkedListModule.partition (fun x -> x >= prog) userList
                printf "Spełniające warunek: "
                LinkedListModule.printList spelnia
                printf "Pozostałe: "
                LinkedListModule.printList reszta

            | _ ->
                printfn "Nieprawidłowa opcja."

        0