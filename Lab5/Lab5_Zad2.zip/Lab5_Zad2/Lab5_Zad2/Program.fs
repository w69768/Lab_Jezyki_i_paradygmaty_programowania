﻿open System

type BinaryTree<'T> =
    | Empty
    | Node of 'T * BinaryTree<'T> * BinaryTree<'T>

let tree = Node(10, 
                Node(5, 
                     Node(3, Empty, Empty), 
                     Node(7, Empty, Empty)), 
                Node(15, 
                     Node(12, Empty, Empty), 
                     Node(18, Empty, Empty)))

let rec findRecursive tree value =
    match tree with
    | Empty -> false
    | Node (v, left, right) ->
        if v = value then true
        else
            findRecursive left value || findRecursive right value

let findIterative tree value =
    let rec loop stack =
        match stack with
        | [] -> false
        | Empty :: tail -> loop tail
        | Node (v, left, right) :: tail ->
            if v = value then true
            else loop (left :: right :: tail)
    loop [tree]

let resultRecursive = findRecursive tree 7
let resultIterative = findIterative tree 7

printfn "Rekurencyjne: Czy 7 jest w drzewie? %b" resultRecursive
printfn "Iteracyjne: Czy 7 jest w drzewie? %b" resultIterative

0