﻿open System

let rec quickSortRekurencyjne lista =
    match lista with
    | [] -> []
    | piwot :: ogon ->
        let mniejsze, wieksze = List.partition (fun x -> x < piwot) ogon
        (quickSortRekurencyjne mniejsze) @ (piwot :: quickSortRekurencyjne wieksze)

let lista = [3; 6; 8; 10; 1; 2; 1]
let posortowanaLista = quickSortRekurencyjne lista
printfn "Posortowana lista (rekurencyjna): %A" posortowanaLista

let quickSortIteracyjne (tablica: 'a[]) =
    let mutable stos = [(0, tablica.Length - 1)]
    let mutable wynik = tablica

    while stos.Length > 0 do
        let (dolnyIndeks, gornyIndeks) = stos.Head
        stos <- stos.Tail
        
        if dolnyIndeks < gornyIndeks then
            let piwot = wynik.[(dolnyIndeks + gornyIndeks) / 2]
            let mutable lewy = dolnyIndeks
            let mutable prawy = gornyIndeks
            
            while lewy <= prawy do
                while wynik.[lewy] < piwot do
                    lewy <- lewy + 1
                while wynik.[prawy] > piwot do
                    prawy <- prawy - 1
                
                if lewy <= prawy then
                    let tymczasowa = wynik.[lewy]
                    wynik.[lewy] <- wynik.[prawy]
                    wynik.[prawy] <- tymczasowa
                    lewy <- lewy + 1
                    prawy <- prawy - 1
            
            if dolnyIndeks < prawy then stos <- (dolnyIndeks, prawy) :: stos
            if lewy < gornyIndeks then stos <- (lewy, gornyIndeks) :: stos

    wynik

let tablicaIteracyjna = [| 3; 6; 8; 10; 1; 2; 1 |]
let posortowanaTablicaIteracyjna = quickSortIteracyjne tablicaIteracyjna
printfn "Posortowana lista (iteracyjna): %A" posortowanaTablicaIteracyjna

0