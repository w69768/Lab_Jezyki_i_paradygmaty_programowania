﻿// For more information see https://aka.ms/fsharp-console-apps
open System

let rec readInt prompt = 
    printfn "%s" prompt
    let line = Console.ReadLine()
    match Int32.TryParse(line) with 
        | true, value -> value
        | _ ->
                printfn "Błąd: podaj poprawną liczbę całkowitą!"
                readInt prompt

[<EntryPoint>]
let main _ = 
    let n = readInt "Podaj ilośc liczb n=  "

    if n <= 0 then
        printfn "Bład: liczba elementów musi być większa od zero"
    else
        //wczytwanie liczb
        let rec readItem k acc =
            if k = 0 then List.rev acc
            else
                let x = readInt (sprintf "Podaj liczbę %d: " (n-k+1))
                readItem (k-1) (x::acc)

        let liczby  = readItem n []

        //obliczenia
        let suma = List.sum liczby
        let min = List.min liczby
        let max = List.max liczby
        let avg = float suma / float n

        printfn "Wprowadzone liczby: %A" liczby
        printfn "Suma %d" suma
        printfn "Min %d" min
        printfn "Max %d" max
        printfn "Max %f" avg

    0
