﻿open System

let pobierzLiczby () =
    printfn "Podaj liczby całkowite oddzielone spacjami:"
    let input = Console.ReadLine()
    input.Split(' ') 
    |> Array.toList 
    |> List.map int

[<EntryPoint>]
let main argv =
    let liczby = pobierzLiczby()

    let liczbyDodatnie = List.filter (fun x -> x > 0) liczby
    printfn "Liczb dodatnich: %d" (List.length liczbyDodatnie)

    let kwadraty = List.map (fun x -> x * x) liczby
    printfn "Kwadraty liczb: %A" kwadraty

    let suma = List.fold (+) 0 liczby
    printfn "Suma liczb: %d" suma

    0
