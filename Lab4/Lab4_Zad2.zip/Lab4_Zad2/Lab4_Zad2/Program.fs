﻿open System

let jestParzysta liczba = liczba % 2 = 0

let jestPodzielnaPrzez3 liczba = liczba % 3 = 0

let typLiczby liczba =
    if liczba < 0 then "ujemna"
    elif liczba = 0 then "zero"
    else "dodatnia"

[<EntryPoint>]
let main argv =
    printfn "Podaj pierwsza liczbę (a):"
    let a = int (Console.ReadLine())

    printfn "Podaj drugą liczbę (b):"
    let b = int (Console.ReadLine())

    let (a, b) = if a > b then (b, a) else (a, b)

    let mutable liczbyParzyste = 0
    let mutable liczbyNieparzyste = 0
    let mutable liczbyUjemne = 0
    let mutable liczbyZero = 0
    let mutable liczbyDodatnie = 0
    let mutable liczbyPodzielnePrzez3 = 0

    printfn "Liczby z przedziału [%d; %d] i ich właściwości:" a b
    for i in a .. b do
        printfn "Liczba %d: %s, %s, %s" i
            (if jestParzysta i then "parzysta" else "nieparzysta")
            (typLiczby i)
            (if jestPodzielnaPrzez3 i then "podzielna przez 3" else "niepodzielna przez 3")

        if jestParzysta i then liczbyParzyste <- liczbyParzyste + 1
        else liczbyNieparzyste <- liczbyNieparzyste + 1

        if i < 0 then liczbyUjemne <- liczbyUjemne + 1
        elif i = 0 then liczbyZero <- liczbyZero + 1
        else liczbyDodatnie <- liczbyDodatnie + 1

        if jestPodzielnaPrzez3 i then liczbyPodzielnePrzez3 <- liczbyPodzielnePrzez3 + 1

    printfn "\nPodsumowanie:"
    printfn "Liczb parzystych: %d" liczbyParzyste
    printfn "Liczb nieparzystych: %d" liczbyNieparzyste
    printfn "Liczb ujemnych: %d" liczbyUjemne
    printfn "Liczb zer: %d" liczbyZero
    printfn "Liczb dodatnich: %d" liczbyDodatnie
    printfn "Liczb podzielnych przez 3: %d" liczbyPodzielnePrzez3

    0