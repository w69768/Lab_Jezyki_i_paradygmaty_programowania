﻿open System

type Student = {
    Name: string
    Age: int
    Grade: float
}

let studenci = [
    { Name = "Jan"; Age = 20; Grade = 4.5 }
    { Name = "Anna"; Age = 22; Grade = 3.8 }
    { Name = "Piotr"; Age = 23; Grade = 5.0 }
    { Name = "Maria"; Age = 21; Grade = 4.2 }
]


let studenciZOcenaGreaterThan4 = 
    List.filter (fun student -> student.Grade >= 4.0) studenci

let studenciPoZwiekszeniuWiek = 
    List.map (fun student -> { student with Age = student.Age + 1 }) studenci

printfn "Studenci z oceną >= 4.0:"
studenciZOcenaGreaterThan4 |> List.iter (fun s -> printfn "%s, wiek: %d, ocena: %.2f" s.Name s.Age s.Grade)

printfn "\nStudenci po zwiększeniu wieku o 1 rok:"
studenciPoZwiekszeniuWiek |> List.iter (fun s -> printfn "%s, wiek: %d, ocena: %.2f" s.Name s.Age s.Grade)
